import express from 'express';
import Chat  from '../models/Chat.js';

const router = express.Router();

router.get('/', async (req, res) => {
  try {
    const chats = await Chat.find()
      .populate('lastMessage')
      .sort({ updatedAt: -1 });
    res.json(chats);
  } catch (error) {
    res.status(500).json({ error: 'Error fetching chats' });
  }
});

 const chatRoutes = router;

 export default chatRoutes;