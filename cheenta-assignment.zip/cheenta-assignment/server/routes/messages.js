import express from 'express';
import  Message  from '../models/Message.js';
import Chat  from '../models/Chat.js';

const router = express.Router();

router.get('/:chatId', async (req, res) => {
  try {
    const messages = await Message.find({ chatId: req.params.chatId })
      .sort({ createdAt: -1 })
      .limit(50);
    res.json(messages);
  } catch (error) {
    res.status(500).json({ error: 'Error fetching messages' });
  }
});

router.post('/', async (req, res) => {
  try {
    const message = new Message(req.body);
    await message.save();
    
    // Update last message in chat
    await Chat.findByIdAndUpdate(req.body.chatId, {
      lastMessage: message._id,
      updatedAt: new Date(),
    });
    
    res.json(message);
  } catch (error) {
    res.status(500).json({ error: 'Error creating message' });
  }
});

 const messageRoutes = router;

 export default messageRoutes;