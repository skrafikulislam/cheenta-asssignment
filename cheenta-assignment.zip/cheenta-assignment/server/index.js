import express from "express";
import { createServer } from "http";
import { Server } from "socket.io";
import cors from "cors";
import multer from "multer";
import path from "path";
import messageRoutes from "./routes/messages.js";
import chatRoutes from "./routes/chats.js";
import setupSocketHandlers from "./socket.js";
import dbConnection from "./db/dbConnection.js";
import dotenv from "dotenv";
import cloudinary from "./config/cloudinary.js";
import { Readable } from "stream";

const app = express();

const httpServer = createServer(app);

const io = new Server(httpServer, {
  cors: {
    origin: "*",
    methods: ["GET", "POST", "PUT", "PATCH", "DELETE"],
  },
});

dotenv.config();

app.use(express.json());
app.use(cors("*"));

// Configure multer for image uploads
const upload = multer({ storage: multer.memoryStorage() });

// Routes
app.use("/api/messages", messageRoutes);
app.use("/api/chats", chatRoutes);

// Image upload endpoint
app.post("/api/upload", upload.single("image"), async (req, res) => {
  if (!req.file) {
    return res.status(400).json({ error: "No file uploaded" });
  }

  try {
    // Convert buffer to stream
    const stream = Readable.from(req.file.buffer);

    // Upload to Cloudinary
    const uploadResponse = await new Promise((resolve, reject) => {
      const uploadStream = cloudinary.uploader.upload_stream(
        {
          folder: "chat-app",
          resource_type: "auto",
        },
        (error, result) => {
          if (error) reject(error);
          resolve(result);
        }
      );

      stream.pipe(uploadStream);
    });

    res.json({ imageUrl: uploadResponse.secure_url });
  } catch (error) {
    console.error("Error uploading to Cloudinary:", error);
    res.status(500).json({ error: "Error uploading image" });
  }
});

// Setup Socket.IO handlers
setupSocketHandlers(io);

dbConnection();

const PORT = process.env.PORT || 3000;
httpServer.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});

console.log(process.env.MONGO_CONNECTION);
