import React, { useState, useEffect } from "react";
import {
  View,
  FlatList,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  KeyboardAvoidingView,
  Platform,
} from "react-native";
import * as ImagePicker from "expo-image-picker";
import { useDispatch, useSelector } from "react-redux";
import { setMessages, addMessage } from "../store/chatSlice";
import { socket } from "../socket";
import { MessageItem } from "../components/MessageItem";
// import http://localhost:5000} from "../config/config";
import { Ionicons } from "@expo/vector-icons";

const ChatScreen = ({ route }) => {
  const [messageText, setMessageText] = useState("");
  const dispatch = useDispatch();
  const messages = useSelector((state) => state.chat.messages);
  const chat = route.params.chat;

  useEffect(() => {
    (async () => {
      const { status } =
        await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (status !== "granted") {
        alert("Sorry, we need camera roll permissions to upload images!");
      }
    })();
  }, []);

  useEffect(() => {
    socket.emit("joinChat", chat._id);
    fetchMessages();

    socket.on("newMessage", (message) => {
      dispatch(addMessage(message));
    });

    return () => {
      socket.off("newMessage");
      socket.emit("leaveChat", chat._id);
    };
  }, [chat._id]);

  const fetchMessages = async () => {
    try {
      const response = await fetch(`http://localhost:5000/api/messages/${chat._id}`);
      const data = await response.json();
      dispatch(setMessages(data));
    } catch (error) {
      console.error("Error fetching messages:", error);
    }
  };

  const handleSendMessage = async () => {
    if (!messageText.trim()) return;

    const message = {
      chatId: chat._id,
      messageText,
      senderId: "currentUserId",  
      receiverId: chat.participants[1]._id,
    };

    try {
      const response = await fetch(`http://localhost:5000/api/messages`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(message),
      });
      const newMessage = await response.json();
      socket.emit("sendMessage", newMessage);
      dispatch(addMessage(newMessage));
      setMessageText("");
    } catch (error) {
      console.error("Error sending message:", error);
    }
  };

  const handleImageUpload = async () => {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [4, 3],
      quality: 1,
    });

    if (!result.canceled && result.assets[0]) {
      const formData = new FormData();
      formData.append("image", {
        uri: result.assets[0].uri,
        type: "image/jpeg",
        name: "photo.jpg",
      });

      try {
        const response = await fetch(`http://localhost:5000/api/upload`, {
          method: "POST",
          body: formData,
          headers: {
            "Content-Type": "multipart/form-data",
          },
        });
        const { imageUrl } = await response.json();

        const message = {
          chatId: chat._id,
          imageUrl,
          senderId: "currentUserId",
          receiverId: chat.participants[1]._id,
        };

        const msgResponse = await fetch(`http://localhost:5000/api/messages`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(message),
        });

        const newMessage = await msgResponse.json();
        socket.emit("sendMessage", newMessage);
        dispatch(addMessage(newMessage));
      } catch (error) {
        console.error("Error uploading image:", error);
      }
    }

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === "ios" ? "padding" : undefined}
      keyboardVerticalOffset={Platform.OS === "ios" ? 90 : 0}
    >
      <FlatList
        data={messages}
        renderItem={({ item }) => (
          <MessageItem
            message={item}
            isOwnMessage={item.senderId === "currentUserId"}
          />
        )}
        keyExtractor={(item) => item._id}
        inverted
      />
      <View style={styles.inputContainer}>
        <TouchableOpacity
          onPress={handleImageUpload}
          style={styles.imageButton}
        >
          <Ionicons name="image" size={24} color="#007AFF" />
        </TouchableOpacity>
        <TextInput
          style={styles.input}
          value={messageText}
          onChangeText={setMessageText}
          placeholder="Type a message..."
          multiline
        />
        <TouchableOpacity
          onPress={handleSendMessage}
          style={styles.sendButton}
          disabled={!messageText.trim()}
        >
          <Ionicons
            name="send"
            size={24}
            color={messageText.trim() ? "#007AFF" : "#C7C7CC"}
          />
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
  },
  inputContainer: {
    flexDirection: "row",
    padding: 10,
    borderTopWidth: 1,
    borderTopColor: "#E5E5EA",
    alignItems: "center",
  },
  input: {
    flex: 1,
    borderWidth: 1,
    borderColor: "#E5E5EA",
    borderRadius: 20,
    paddingHorizontal: 15,
    paddingVertical: 8,
    marginHorizontal: 10,
    maxHeight: 100,
  },
  imageButton: {
    padding: 10,
  },
  sendButton: {
    padding: 10,
  },
});
}

export default ChatScreen;
