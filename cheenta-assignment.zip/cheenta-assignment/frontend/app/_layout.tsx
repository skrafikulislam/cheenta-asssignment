import { Stack } from "expo-router";
import { StatusBar } from "expo-status-bar";
import React from "react";
import "react-native-reanimated";
import "../global.css";
import { Provider } from "react-redux";
import { store } from "../store/store";
// import useColorScheme from "../hooks/useColorScheme";

export default function _layout() {
  return (
    // <ThemeProvider value={colorScheme === "dark" ? DarkTheme : DefaultTheme}>
    <Provider store={store}>
      <StatusBar style="auto" />
      <Stack>
        <Stack.Screen name="ChatList" />
        <Stack.Screen name="Chat" />
      </Stack>
    </Provider>
    // </ThemeProvider>
  );
}
