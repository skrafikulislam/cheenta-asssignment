import React from "react";
import { TouchableOpacity, Image, View, Text, StyleSheet } from "react-native";
 

const ChatItem = ({ chat, onPress }) => {
  return (
    <TouchableOpacity style={styles.container} onPress={onPress}>
      <Image
        style={styles.avatar}
        source={{ uri: chat.participants[1].avatar }}
        defaultSource={require("../assets/images/avatar-pic.png")}
      />
      <View style={styles.content}>
        <Text style={styles.name}>{chat.participants[1].name}</Text>
        <Text style={styles.lastMessage} numberOfLines={1}>
          {chat.lastMessage?.messageText || "No messages yet"}
        </Text>
      </View>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: "row",
    padding: 15,
    borderBottomWidth: 1,
    borderBottomColor: "#E5E5EA",
  },
  avatar: {
    width: 50,
    height: 50,
    borderRadius: 25,
  },
  content: {
    marginLeft: 15,
    flex: 1,
    justifyContent: "center",
  },
  name: {
    fontSize: 16,
    fontWeight: "bold",
    marginBottom: 4,
  },
  lastMessage: {
    fontSize: 14,
    color: "#666",
  },
});

export default ChatItem;
