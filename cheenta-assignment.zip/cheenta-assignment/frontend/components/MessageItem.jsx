import React from 'react';
import { View, Text, Image, StyleSheet } from 'react-native';

const MessageItem = ({ message, isOwnMessage }) => {
  return (
    <View
      style={[
        styles.container,
        isOwnMessage ? styles.ownMessage : styles.otherMessage,
      ]}
    >
      {message.imageUrl && (
        <Image
          source={{ uri: message.imageUrl }}
          style={styles.image}
          resizeMode="cover"
        />
      )}
      {message.messageText && (
        <Text
          style={[
            styles.text,
            isOwnMessage ? styles.ownText : styles.otherText,
          ]}
        >
          {message.messageText}
        </Text>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    maxWidth: '80%',
    marginVertical: 5,
    marginHorizontal: 10,
    padding: 10,
    borderRadius: 15,
  },
  ownMessage: {
    alignSelf: 'flex-end',
    backgroundColor: '#007AFF',
  },
  otherMessage: {
    alignSelf: 'flex-start',
    backgroundColor: '#E5E5EA',
  },
  text: {
    fontSize: 16,
  },
  ownText: {
    color: '#FFFFFF',
  },
  otherText: {
    color: '#000000',
  },
  image: {
    width: 200,
    height: 200,
    borderRadius: 10,
    marginBottom: 5,
  },
});

export default MessageItem;
